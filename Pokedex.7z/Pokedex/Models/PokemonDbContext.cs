using Microsoft.EntityFrameworkCore;

namespace Pokedex.Models
{
    public class PokemonDbContext : DbContext
    {
        public DbSet<Pokemon> Pokemones { get; set; }
//base llama al constructor del padre
        public PokemonDbContext(DbContextOptions<PokemonDbContext> o) : base(o) 
        {
            
        }
    }
}